﻿using System;

namespace sas
{
    partial class sas
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button = new System.Windows.Forms.Button();
            this.textBox = new System.Windows.Forms.TextBox();
            this.labelT = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button
            // 
            this.button.Location = new System.Drawing.Point(366, 313);
            this.button.Name = "button";
            this.button.Size = new System.Drawing.Size(75, 23);
            this.button.TabIndex = 0;
            this.button.Text = "Press";
            this.button.UseVisualStyleBackColor = true;
            this.button.Click += new System.EventHandler(this.button_Click);
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(236, 287);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(342, 20);
            this.textBox.TabIndex = 1;
            this.textBox.Text = "name plz";
            this.textBox.TextChanged += new System.EventHandler(this.textBox_TextChanged_1);
            // 
            // labelT
            // 
            this.labelT.AutoSize = true;
            this.labelT.Location = new System.Drawing.Point(385, 271);
            this.labelT.Name = "labelT";
            this.labelT.Size = new System.Drawing.Size(35, 13);
            this.labelT.TabIndex = 3;
            this.labelT.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(264, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // sas
            // 
            this.ClientSize = new System.Drawing.Size(848, 488);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelT);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.button);
            this.Name = "sas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lol;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button;
        private System.Windows.Forms.TextBox textBox;
        private EventHandler textBox_TextChanged;
        private System.Windows.Forms.Label labelT;
        private System.Windows.Forms.Label label1;
    }
}

