﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sas
{
    public partial class sas : Form
    {
        new string name = "";
        new int clicks = 0;
        public sas()
        {
            InitializeComponent();
        }
        private void button_Click(object sender, EventArgs e)
        {
            labelT.Text = name;
        }

        private void textBox_TextChanged_1(object sender, EventArgs e)
        {
             name = textBox.Text;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            clicks++;
            label1.Text = clicks.ToString();
        }
    }
}
